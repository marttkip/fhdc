<!-- Today status. jQuery Sparkline plugin used. -->
<div class="row">
	<div class="col-md-12">
		<?php echo $this->load->view('accounts/dashboard/summary', '', TRUE);?>
	</div>
</div>